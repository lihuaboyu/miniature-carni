/* ============================================================
   暖心智服 · 静态展示站交互
   - 语言切换 / 大字模式 / 移动菜单
   - 照片墙、视频、联系方式均从 config.js 读取并渲染
   - 没配置的内容显示友好空状态，不会出现裂图或虚假信息
   ============================================================ */
(function () {
  'use strict';

  // 每次渲染都重新读取配置，保证修改 config.js 后（以及运行期更新）都能生效
  function getCfg() { return window.SITE_CONFIG || { contact: {}, gallery: [], videos: [] }; }
  const t = (key) => (window.I18N ? window.I18N.t(key) : key);
  const lang = () => (window.I18N ? window.I18N.lang : 'zh');

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ---------------- 提示条 ---------------- */
  let toastTimer = null;
  function toast(msg) {
    let el = document.getElementById('toast');
    if (!el) { el = document.createElement('div'); el.id = 'toast'; el.className = 'toast'; document.body.appendChild(el); }
    el.textContent = msg;
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 3200);
  }

  /* ---------------- 图标（统一线性风格） ---------------- */
  const ICON = {
    phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l1.5 5-2.5 2a14 14 0 0 0 6 6l2-2.5 5 1.5V20a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg>',
    wechat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8 8 0 0 1-11.5 7.2L4 20l1.4-4.2A8 8 0 1 1 21 11.5z"/><path d="M8.5 10.5h.01M14.5 10.5h.01"/></svg>',
    heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/></svg>',
    pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-7-5.7-7-11a7 7 0 0 1 14 0c0 5.3-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>',
    hotline: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11a8 8 0 0 1 16 0"/><path d="M4 11a8 8 0 0 0 16 0"/><path d="M12 19v2"/><path d="M8 15h8"/></svg>',
    emergency: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l9 16H3z"/><path d="M12 10v4M12 17h.01"/></svg>',
    image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M21 16l-5-4L6 19"/></svg>',
    video: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3z"/></svg>'
  };

  /* ---------------- 双语取值（维文为空时回退中文） ---------------- */
  function bi(item, zhKey, ugKey) {
    const zh = item[zhKey] || '';
    const ug = item[ugKey] || '';
    if (lang() === 'ug') return ug || zh;
    return zh;
  }

  /* ---------------- 照片墙 ---------------- */
  function renderGallery() {
    const grid = document.getElementById('galleryGrid');
    if (!grid) return;
    const cfg = getCfg();
    const items = (cfg.gallery || []).filter((it) => it && it.src);
    if (!items.length) {
      grid.innerHTML =
        '<div class="gallery-empty">' + ICON.image +
        '<p data-i18n="gallery.empty">' + esc(t('gallery.empty')) + '</p>' +
        '<p class="empty-hint" data-i18n="gallery.empty_hint">' + esc(t('gallery.empty_hint')) + '</p>' +
        '</div>';
      return;
    }
    grid.innerHTML = items.map((it) => {
      const cap = bi(it, 'caption_zh', 'caption_ug');
      return (
        '<figure class="gallery-item" data-full="' + esc(it.src) + '" tabindex="0" role="button" aria-label="' + esc(cap || t('gallery.title')) + '">' +
          '<img class="gallery-photo" src="' + esc(it.src) + '" alt="' + esc(cap) + '" loading="lazy">' +
          (cap ? '<figcaption class="gallery-caption">' + esc(cap) + '</figcaption>' : '') +
        '</figure>'
      );
    }).join('');
  }

  /* ---------------- 视频 ---------------- */
  function renderVideos() {
    const wrap = document.getElementById('videoWrap');
    if (!wrap) return;
    const cfg = getCfg();
    const vids = (cfg.videos || []).filter((v) => v && v.url);
    if (!vids.length) {
      wrap.innerHTML =
        '<div class="video-empty">' + ICON.video +
        '<p data-i18n="video.empty">' + esc(t('video.empty')) + '</p>' +
        '</div>';
      return;
    }
    wrap.innerHTML = vids.map((v) => {
      const title = bi(v, 'title_zh', 'title_ug') || '';
      const safeUrl = /^https?:\/\//i.test(v.url) ? v.url : '';
      if (!safeUrl) return '';
      return (
        '<div class="video-block">' +
          (title ? '<h3 class="video-title">' + esc(title) + '</h3>' : '') +
          '<div class="video-frame"><iframe src="' + esc(safeUrl) +
            '" title="' + esc(title) + '" loading="lazy" allowfullscreen referrerpolicy="no-referrer"></iframe></div>' +
        '</div>'
      );
    }).join('');
  }

  /* ---------------- 联系方式 ---------------- */
  function renderContact() {
    const box = document.getElementById('contactGrid');
    if (!box) return;
    const cfg = getCfg();
    const c = cfg.contact || {};
    let html = '';

    if (c.apply_form_url && /^https?:\/\//i.test(c.apply_form_url)) {
      html +=
        '<div class="contact-card"><div class="contact-icon">' + ICON.heart + '</div>' +
        '<h3 data-i18n="contact.apply">' + esc(t('contact.apply')) + '</h3>' +
        '<button class="btn-primary" id="contactApply" type="button" data-url="' + esc(c.apply_form_url) + '">' +
        esc(t('hero.cta_apply')) + '</button></div>';
    }
    if (c.phone) {
      html +=
        '<div class="contact-card"><div class="contact-icon">' + ICON.phone + '</div>' +
        '<h3 data-i18n="contact.phone">' + esc(t('contact.phone')) + '</h3>' +
        '<a class="contact-value" href="tel:' + esc(c.phone.replace(/[^\d+]/g, '')) + '">' + esc(c.phone) + '</a></div>';
    }
    if (c.wechat_qr) {
      html +=
        '<div class="contact-card"><div class="contact-icon">' + ICON.wechat + '</div>' +
        '<h3 data-i18n="contact.wechat">' + esc(t('contact.wechat')) + '</h3>' +
        '<img class="contact-qr" src="' + esc(c.wechat_qr) + '" alt="' + esc(t('contact.qr_tip')) + '">' +
        '<span class="contact-value" style="font-size:13px;font-weight:500" data-i18n="contact.qr_tip">' + esc(t('contact.qr_tip')) + '</span></div>';
    }
    if (c.address) {
      html +=
        '<div class="contact-card"><div class="contact-icon">' + ICON.pin + '</div>' +
        '<h3 data-i18n="contact.address">' + esc(t('contact.address')) + '</h3>' +
        '<span class="contact-value">' + esc(c.address) + '</span></div>';
    }
    // 公开热线（真实公共号码，始终展示）
    html +=
      '<div class="contact-card is-hotline"><div class="contact-icon">' + ICON.hotline + '</div>' +
      '<h3>政务服务</h3>' +
      '<a class="contact-value" href="tel:12345">12345</a>' +
      '<span class="contact-value" style="font-size:12.5px;font-weight:500" data-i18n="contact.hotline">' + esc(t('contact.hotline')) + '</span></div>';
    html +=
      '<div class="contact-card is-hotline"><div class="contact-icon">' + ICON.emergency + '</div>' +
      '<h3>紧急求助</h3>' +
      '<span class="contact-value">110 · 120 · 119</span>' +
      '<span class="contact-value" style="font-size:12.5px;font-weight:500" data-i18n="contact.emergency">' + esc(t('contact.emergency')) + '</span></div>';

    if (!c.phone && !c.wechat_qr && !c.address && !c.apply_form_url) {
      html = '<div class="contact-empty" data-i18n="contact.empty">' + esc(t('contact.empty')) + '</div>' + html;
    }
    box.innerHTML = html;
  }

  function renderDynamic() {
    renderGallery();
    renderVideos();
    renderContact();
  }

  /* ---------------- 打开申请链接 ---------------- */
  function openApply() {
    const cfg = getCfg();
    const url = cfg.contact && cfg.contact.apply_form_url;
    if (url && /^https?:\/\//i.test(url)) {
      window.open(url, '_blank', 'noopener');
    } else {
      toast(t('hero.apply_note'));
    }
  }

  /* ---------------- 初始化 ---------------- */
  document.addEventListener('DOMContentLoaded', function () {
    // 首次应用语言（静态文本）
    window.I18N.applyLang(window.I18N.lang);

    // 大字模式（记忆选择）
    const fontToggle = document.getElementById('fontToggle');
    if (localStorage.getItem('nxf_large') === '1') {
      document.documentElement.classList.add('large-font');
      fontToggle.setAttribute('aria-pressed', 'true');
    }
    fontToggle.addEventListener('click', function () {
      const on = document.documentElement.classList.toggle('large-font');
      fontToggle.setAttribute('aria-pressed', String(on));
      localStorage.setItem('nxf_large', on ? '1' : '0');
      toast(t(on ? 'a11y.large_on' : 'a11y.large_off'));
    });

    // 语言切换
    document.getElementById('langToggle').addEventListener('click', function () {
      window.I18N.toggleLang();
    });

    // 动态内容（语言切换后重渲染，保证维文说明同步）
    window.addEventListener('langchange', function (e) {
      const isUg = e.detail.lang === 'ug';
      document.getElementById('ugNotice').hidden = !isUg;
      renderDynamic();
    });
    // 初始时若已是 ug，提示条也要显示
    document.getElementById('ugNotice').hidden = !(window.I18N.lang === 'ug');
    renderDynamic();

    // 移动菜单
    const menuToggle = document.getElementById('menuToggle');
    const navLinks = document.getElementById('navLinks');
    menuToggle.addEventListener('click', function () {
      const open = navLinks.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', String(open));
    });
    navLinks.querySelectorAll('a').forEach((a) => {
      a.addEventListener('click', () => {
        navLinks.classList.remove('open');
        menuToggle.setAttribute('aria-expanded', 'false');
      });
    });

    // 申请按钮（hero + 动态联系区，事件委托）
    document.getElementById('applyBtn').addEventListener('click', openApply);
    document.addEventListener('click', function (e) {
      const contactApply = e.target.closest('#contactApply');
      if (contactApply) {
        const url = contactApply.getAttribute('data-url');
        if (url && /^https?:\/\//i.test(url)) window.open(url, '_blank', 'noopener');
        else toast(t('hero.apply_note'));
      }
    });

    // 照片灯箱（事件委托）
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightboxImg');
    function openLightbox(src, alt) {
      lightboxImg.src = src;
      lightboxImg.alt = alt || '';
      lightbox.hidden = false;
    }
    function closeLightbox() { lightbox.hidden = true; lightboxImg.src = ''; }
    document.addEventListener('click', function (e) {
      const item = e.target.closest('.gallery-item');
      if (item) openLightbox(item.getAttribute('data-full'), item.getAttribute('aria-label'));
      if (e.target === lightbox) closeLightbox();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && e.target.classList && e.target.classList.contains('gallery-item')) {
        openLightbox(e.target.getAttribute('data-full'), e.target.getAttribute('aria-label'));
      }
      if (e.key === 'Escape' && !lightbox.hidden) closeLightbox();
    });
    document.getElementById('lightboxClose').addEventListener('click', closeLightbox);
  });
})();
